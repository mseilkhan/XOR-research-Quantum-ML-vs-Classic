from __future__ import annotations

"""
Experiment 2 — Learning behavior
- MLP(h=4): train/test loss, train/test acc, test loss across seeds
- VQC:
  - L=1 analytic: train/test loss
  - L=1 shots=128: train/test loss
  - L=2 analytic: test loss across seeds
Artifacts: square learning-curve figures + optional CSV histories.
"""

import os
from typing import Dict, List

import numpy as np

from core.data.xor_dataset import make_split
from core.train.trainer import TrainConfig, Trainer
from core.viz.learning_curves import (
    plot_train_test_curves,
    plot_test_loss_across_seeds,
)

from experiments.settings import (
    DATASET_SEED, SPLIT_SEED, MODEL_SEEDS,
    FIG_DIR, CSV_DIR,
    MLP_HP, VQC_HP,
)
from experiments.utils import ensure_output_dirs, save_records_csv, tag_shots
from experiments.models_factory import make_mlp, make_vqc


def history_to_rows(history: Dict[str, np.ndarray], meta: Dict[str, str]) -> List[dict]:
    rows = []
    epochs = len(history["train_loss"])
    for i in range(epochs):
        rows.append({
            **meta,
            "epoch": i + 1,
            "train_loss": float(history["train_loss"][i]),
            "test_loss": float(history["test_loss"][i]),
            "train_acc": float(history["train_acc"][i]),
            "test_acc": float(history["test_acc"][i]),
        })
    return rows


def main():
    ensure_output_dirs(FIG_DIR, CSV_DIR)

    # Use benchmark dataset for learning curves (Dataset B, σ=0.10, n=100)
    split = make_split("B", sigma=0.10, n_per_cluster=100, data_seed=DATASET_SEED, split_seed=SPLIT_SEED)
    trainer_mlp = Trainer(TrainConfig(MLP_HP.epochs, MLP_HP.lr))
    trainer_vqc = Trainer(TrainConfig(VQC_HP.epochs, VQC_HP.lr))

    # ---------------- MLP(h=4) ----------------
    mlp_spec, mlp_factory = make_mlp(h=4)

    # representative run = seed 0
    mlp0 = mlp_factory(0)
    res0 = trainer_mlp.fit(mlp0, split.X_train, split.y_train, split.X_test, split.y_test)

    plot_train_test_curves(
        history=res0.history,
        title=f"{mlp_spec.name} — Train/Test Loss (Dataset B σ=0.10, n=100)",
        ylabel="BCE loss",
        key_train="train_loss",
        key_test="test_loss",
        out_path=os.path.join(FIG_DIR, "lc_mlp_h4_loss.png"),
    )
    plot_train_test_curves(
        history=res0.history,
        title=f"{mlp_spec.name} — Train/Test Accuracy (Dataset B σ=0.10, n=100)",
        ylabel="accuracy",
        key_train="train_acc",
        key_test="test_acc",
        out_path=os.path.join(FIG_DIR, "lc_mlp_h4_acc.png"),
    )

    # test loss across seeds
    histories = []
    for s in MODEL_SEEDS:
        m = mlp_factory(s)
        r = trainer_mlp.fit(m, split.X_train, split.y_train, split.X_test, split.y_test)
        histories.append(r.history)
    plot_test_loss_across_seeds(
        histories=histories,
        title=f"{mlp_spec.name} — Test Loss Across Seeds (Dataset B σ=0.10, n=100)",
        out_path=os.path.join(FIG_DIR, "lc_mlp_h4_testloss_seeds.png"),
    )

    # optionally save representative history
    save_records_csv(
        os.path.join(CSV_DIR, "lc_mlp_h4_seed0.csv"),
        history_to_rows(res0.history, {"model": mlp_spec.name, "seed": "0"}),
    )

    # ---------------- VQC (L=1) analytic & 128 shots ----------------
    for shots in [None, 128]:
        vqc_spec, vqc_factory = make_vqc(L=1, shots=shots)
        v = vqc_factory(0)
        r = trainer_vqc.fit(v, split.X_train, split.y_train, split.X_test, split.y_test)

        plot_train_test_curves(
            history=r.history,
            title=f"{vqc_spec.name} — Train/Test Loss (Dataset B σ=0.10, n=100)",
            ylabel="BCE loss",
            key_train="train_loss",
            key_test="test_loss",
            out_path=os.path.join(FIG_DIR, f"lc_vqc_L1_{tag_shots(shots)}_loss.png"),
        )

        save_records_csv(
            os.path.join(CSV_DIR, f"lc_vqc_L1_{tag_shots(shots)}_seed0.csv"),
            history_to_rows(r.history, {"model": vqc_spec.name, "seed": "0"}),
        )

    # ---------------- VQC (L=2) analytic: test loss across seeds ----------------
    vqc2_spec, vqc2_factory = make_vqc(L=2, shots=None)
    histories_vqc2 = []
    for s in MODEL_SEEDS:
        v = vqc2_factory(s)
        r = trainer_vqc.fit(v, split.X_train, split.y_train, split.X_test, split.y_test)
        histories_vqc2.append(r.history)

    plot_test_loss_across_seeds(
        histories=histories_vqc2,
        title=f"{vqc2_spec.name} — Test Loss Across Seeds (Dataset B σ=0.10, n=100)",
        out_path=os.path.join(FIG_DIR, "lc_vqc_L2_analytic_testloss_seeds.png"),
    )


if __name__ == "__main__":
    main()
