from __future__ import annotations

"""
Experiment 3.3 — VQC shot dependence
- Evaluate VQC accuracy vs shots for a fixed dataset mode (Dataset B, σ=0.10, n=100)
- regimes: analytic, 128, 1024
Artifacts:
- CSV raw + summary
- Plot mean±std curve
"""

import os

from core.data.xor_dataset import make_split
from core.eval.sweeps import run_repeated
from core.train.trainer import TrainConfig
from core.viz.robustness import plot_mean_std_curve

from experiments.settings import (
    DATASET_SEED, SPLIT_SEED, MODEL_SEEDS,
    VQC_HP, FIG_DIR, CSV_DIR,
)
from experiments.utils import ensure_output_dirs, save_records_csv, save_summaries_csv, tag_shots
from experiments.models_factory import make_vqc


def main():
    ensure_output_dirs(FIG_DIR, CSV_DIR)

    split = make_split("B", sigma=0.10, n_per_cluster=100, data_seed=DATASET_SEED, split_seed=SPLIT_SEED)

    all_records = []
    summaries = []

    for shots in [None, 128, 1024]:
        spec, factory = make_vqc(L=1, shots=shots)
        rec, summ = run_repeated(
            model_factory=factory,
            split=split,
            dataset_name="B",
            model_name=spec.name,
            train_cfg=TrainConfig(VQC_HP.epochs, VQC_HP.lr),
            model_seeds=MODEL_SEEDS,
            meta={"sigma": 0.10, "n_per_cluster": 100, "shots": shots, "L": 1},
        )
        all_records.extend(rec)
        summaries.append(summ)

    save_records_csv(os.path.join(CSV_DIR, "vqc_shots_runs.csv"), all_records)
    save_summaries_csv(os.path.join(CSV_DIR, "vqc_shots_summary.csv"), summaries)

    # Plot mean±std accuracy vs shots (use x-axis as 0=analytic then shots)
    xs = [0, 128, 1024]
    ys_m = [s["test_acc_mean"] for s in sorted(summaries, key=lambda r: (r["shots"] is not None, r["shots"] or 0))]
    ys_s = [s["test_acc_std"] for s in sorted(summaries, key=lambda r: (r["shots"] is not None, r["shots"] or 0))]

    plot_mean_std_curve(
        xs=xs,
        ys_mean=ys_m,
        ys_std=ys_s,
        title="VQC(L=1): Accuracy vs shots (Dataset B σ=0.10, n=100)",
        xlabel="shots (0 = analytic)",
        ylabel="test accuracy",
        label="VQC(L=1)",
        out_path=os.path.join(FIG_DIR, "rob_vqc_shots.png"),
    )


if __name__ == "__main__":
    main()
