from __future__ import annotations

"""
Experiment 4 — Summary tables (benchmark mode)
Mode: Dataset B, σ=0.10, n_per_cluster=100
Outputs:
- performance table (train acc, test acc, test loss) mean±std
- cost table (#params, train_seconds) mean±std
- settings tables: exp_settings_data, exp_settings_models, vqc_settings
All in LaTeX-friendly CSV or .tex.
"""

import os
from typing import Dict, Any, List

from core.data.xor_dataset import make_split
from core.eval.sweeps import run_repeated
from core.train.trainer import TrainConfig

from experiments.settings import (
    DATASET_SEED, SPLIT_SEED, MODEL_SEEDS,
    BENCH_SIGMA, BENCH_N,
    TABLE_DIR, CSV_DIR,
    LR_HP, MLP_HP, VQC_HP,
)
from experiments.utils import ensure_output_dirs, save_records_csv, save_summaries_csv
from experiments.models_factory import make_linear, make_mlp, make_vqc


def main():
    ensure_output_dirs(TABLE_DIR, CSV_DIR)

    split = make_split("B", sigma=BENCH_SIGMA, n_per_cluster=BENCH_N, data_seed=DATASET_SEED, split_seed=SPLIT_SEED)

    specs = []
    specs.append((*make_linear(), LR_HP, {"model_group": "classical"}))
    specs.append((*make_mlp(h=4), MLP_HP, {"model_group": "classical"}))
    specs.append((*make_vqc(L=1, shots=None), VQC_HP, {"model_group": "quantum"}))
    specs.append((*make_vqc(L=1, shots=1024), VQC_HP, {"model_group": "quantum"}))
    specs.append((*make_vqc(L=2, shots=None), VQC_HP, {"model_group": "quantum"}))
    specs.append((*make_vqc(L=2, shots=1024), VQC_HP, {"model_group": "quantum"}))

    all_records = []
    summaries = []

    for spec, factory, hp, extra in specs:
        rec, summ = run_repeated(
            model_factory=factory,
            split=split,
            dataset_name="B",
            model_name=spec.name,
            train_cfg=TrainConfig(hp.epochs, hp.lr),
            model_seeds=MODEL_SEEDS,
            meta={
                "sigma": BENCH_SIGMA,
                "n_per_cluster": BENCH_N,
                **extra,
            },
        )
        all_records.extend(rec)
        summaries.append(summ)

    # Save raw + summary
    save_records_csv(os.path.join(CSV_DIR, "summary_benchmark_runs.csv"), all_records)
    save_summaries_csv(os.path.join(CSV_DIR, "summary_benchmark_meanstd.csv"), summaries)

    # Minimal settings tables (data + models) in CSV
    exp_settings_data = [{
        "dataset_seed": DATASET_SEED,
        "split_seed": SPLIT_SEED,
        "train_frac": 0.80,
        "dataset": "B",
        "sigma_grid": str([0.00, 0.05, 0.10, 0.20, 0.30]),
        "n_per_cluster_grid": str([25, 50, 100, 250, 500]),
    }]
    save_summaries_csv(os.path.join(TABLE_DIR, "exp_settings_data.csv"), exp_settings_data)

    exp_settings_models = [
        {"model": "Linear", "params": 3, "epochs": LR_HP.epochs, "lr": LR_HP.lr},
        {"model": "MLP", "activation_hidden": "sigmoid", "activation_out": "sigmoid", "h_grid": str([1,2,4,8]),
         "epochs": MLP_HP.epochs, "lr": MLP_HP.lr},
        {"model": "VQC", "qubits": 2, "encoding": "RX(pi*x1), RX(pi*x2)", "observable": "<Z0>",
         "L_grid": str([1,2]), "shots_grid": str(["analytic", 128, 1024]), "epochs": VQC_HP.epochs, "lr": VQC_HP.lr,
         "n_params": "6L"},
    ]
    save_summaries_csv(os.path.join(TABLE_DIR, "exp_settings_models.csv"), exp_settings_models)

    vqc_settings = []
    for L in [1, 2]:
        for shots in [None, 128, 1024]:
            vqc_settings.append({
                "L": L,
                "shots": "analytic" if shots is None else shots,
                "n_params": 6 * L,
                "encoding": "RX(pi*x1), RX(pi*x2)",
                "observable": "<Z0>",
                "device": "default.qubit",
            })
    save_summaries_csv(os.path.join(TABLE_DIR, "vqc_settings.csv"), vqc_settings)


if __name__ == "__main__":
    main()
