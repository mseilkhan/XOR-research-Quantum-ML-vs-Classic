from __future__ import annotations

"""
Experiment 3.4 — Seed sensitivity
- For a fixed benchmark mode (Dataset B, σ=0.10, n=100),
  log per-seed final test acc and test loss for:
  Linear, MLP(h=4), VQC(L=1 analytic), VQC(L=1 shots=1024), VQC(L=2 analytic), VQC(L=2 shots=1024)
Artifacts:
- CSV per-seed results (acc + bce)
- (Optional) simple plots can be produced later from the CSV
"""

import os
from typing import List, Dict

from core.data.xor_dataset import make_split
from core.train.trainer import TrainConfig, Trainer

from experiments.settings import (
    DATASET_SEED, SPLIT_SEED, MODEL_SEEDS,
    CSV_DIR,
    LR_HP, MLP_HP, VQC_HP,
)
from experiments.utils import ensure_output_dirs, save_summaries_csv
from experiments.models_factory import make_linear, make_mlp, make_vqc


def eval_per_seed(spec_name: str, factory, hp, split) -> List[Dict]:
    trainer = Trainer(TrainConfig(hp.epochs, hp.lr))
    rows = []
    for s in MODEL_SEEDS:
        m = factory(s)
        trainer.fit(m, split.X_train, split.y_train, split.X_test, split.y_test)
        final = Trainer.final_metrics(m, split.X_train, split.y_train, split.X_test, split.y_test)
        rows.append({
            "model": spec_name,
            "seed": s,
            "test_acc": final["test_acc"],
            "test_loss": final["test_loss"],
            "train_acc": final["train_acc"],
            "train_loss": final["train_loss"],
            "n_params": m.n_params(),
        })
    return rows


def main():
    ensure_output_dirs(CSV_DIR)

    split = make_split("B", sigma=0.10, n_per_cluster=100, data_seed=DATASET_SEED, split_seed=SPLIT_SEED)

    specs = []
    specs.append((*make_linear(), LR_HP))
    specs.append((*make_mlp(h=4), MLP_HP))
    specs.append((*make_vqc(L=1, shots=None), VQC_HP))
    specs.append((*make_vqc(L=1, shots=1024), VQC_HP))
    specs.append((*make_vqc(L=2, shots=None), VQC_HP))
    specs.append((*make_vqc(L=2, shots=1024), VQC_HP))

    rows = []
    for spec, factory, hp in specs:
        rows.extend(eval_per_seed(spec.name, factory, hp, split))

    # One flat CSV (easy for plotting)
    save_summaries_csv(os.path.join(CSV_DIR, "seed_sensitivity_runs.csv"), rows)


if __name__ == "__main__":
    main()
