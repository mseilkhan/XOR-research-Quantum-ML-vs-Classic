from __future__ import annotations

"""
Experiment 1 — Decision boundaries
- MLP(h=4): Dataset A, Dataset B sigma=0.10, Dataset B sigma=0.20
- VQC: L=1/2 in analytic and 1024 shots
Artifacts:
- boundary images (square)
- optional seed-representative background (contours across seeds)
"""

import os

from core.data.xor_dataset import make_split
from core.train.trainer import TrainConfig, Trainer
from core.viz.decision_boundary import plot_decision_function, plot_decision_boundary_seed_background

from experiments.settings import (
    DATASET_SEED, SPLIT_SEED, MODEL_SEEDS,
    FIG_DIR, DB_SIGMAS, DB_N_PER_CLUSTER,
    MLP_HP, VQC_HP,
)
from experiments.utils import ensure_output_dirs, tag_shots, tag_sigma, tag_n
from experiments.models_factory import make_mlp, make_vqc


def train_models_across_seeds(model_factory, split, train_cfg: TrainConfig):
    """Train and return list of fitted models across model seeds (for background contours)."""
    trainer = Trainer(train_cfg)
    models = []
    for s in MODEL_SEEDS:
        m = model_factory(s)
        trainer.fit(m, split.X_train, split.y_train, split.X_test, split.y_test)
        models.append(m)
    return models


def main():
    ensure_output_dirs(FIG_DIR)

    # ---------- MLP decision boundaries ----------
    mlp_spec, mlp_factory = make_mlp(h=4)

    # Dataset A
    split_A = make_split("A", data_seed=DATASET_SEED, split_seed=SPLIT_SEED)
    mlp_models_A = train_models_across_seeds(mlp_factory, split_A, TrainConfig(MLP_HP.epochs, MLP_HP.lr))
    out_A = os.path.join(FIG_DIR, f"db_mlp_h4_datasetA.png")
    plot_decision_boundary_seed_background(
        models=mlp_models_A,
        X=split_A.X_train, y=split_A.y_train,
        title=f"{mlp_spec.name} — Dataset A",
        out_path=out_A,
        xlim=(0, 1), ylim=(0, 1),
    )

    # Dataset B: sigma=0.10 and 0.20
    for sigma in DB_SIGMAS:
        split_B = make_split("B", sigma=float(sigma), n_per_cluster=DB_N_PER_CLUSTER,
                             data_seed=DATASET_SEED, split_seed=SPLIT_SEED)
        mlp_models_B = train_models_across_seeds(mlp_factory, split_B, TrainConfig(MLP_HP.epochs, MLP_HP.lr))
        out_B = os.path.join(FIG_DIR, f"db_mlp_h4_datasetB_{tag_sigma(sigma)}_{tag_n(DB_N_PER_CLUSTER)}.png")
        plot_decision_boundary_seed_background(
            models=mlp_models_B,
            X=split_B.X_train, y=split_B.y_train,
            title=f"{mlp_spec.name} — Dataset B (σ={sigma:.2f}, n={DB_N_PER_CLUSTER})",
            out_path=out_B,
            xlim=(0, 1), ylim=(0, 1),
        )

    # ---------- VQC decision boundaries ----------
    # Use Dataset B sigma=0.10, n=100 as representative (your paper uses B as benchmark)
    split_rep = make_split("B", sigma=0.10, n_per_cluster=100, data_seed=DATASET_SEED, split_seed=SPLIT_SEED)

    for L in [1, 2]:
        for shots in [None, 1024]:
            vqc_spec, vqc_factory = make_vqc(L=L, shots=shots)
            vqc_models = train_models_across_seeds(vqc_factory, split_rep, TrainConfig(VQC_HP.epochs, VQC_HP.lr))

            out_path = os.path.join(FIG_DIR, f"db_vqc_L{L}_{tag_shots(shots)}.png")
            plot_decision_boundary_seed_background(
                models=vqc_models,
                X=split_rep.X_train, y=split_rep.y_train,
                title=f"{vqc_spec.name} — Dataset B (σ=0.10, n=100)",
                out_path=out_path,
                xlim=(0, 1), ylim=(0, 1),
            )


if __name__ == "__main__":
    main()
