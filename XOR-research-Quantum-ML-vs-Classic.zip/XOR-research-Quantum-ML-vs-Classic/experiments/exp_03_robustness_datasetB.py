from __future__ import annotations

"""
Experiment 3 — Robustness (Dataset B)
- accuracy vs noise sigma (B, n=100)
- accuracy vs dataset size n_per_cluster (B, sigma=0.10)
- VQC shot dependence handled in separate experiment file (exp_04)
Artifacts:
- CSV raw (per-seed runs) and summaries (mean±std)
- compare plots (square style handled by core.viz)
"""

import os
from typing import List, Dict, Any

from core.eval.sweeps import sweep_noise_datasetB, sweep_size_datasetB
from core.train.trainer import TrainConfig
from core.viz.robustness import plot_mean_std_curve

from experiments.settings import (
    DATASET_SEED, SPLIT_SEED, MODEL_SEEDS,
    NOISE_SWEEP, SIZE_SWEEP,
    FIG_DIR, CSV_DIR,
    LR_HP, MLP_HP, VQC_HP,
)
from experiments.utils import ensure_output_dirs, save_records_csv, save_summaries_csv
from experiments.models_factory import make_linear, make_mlp, make_vqc


def main():
    ensure_output_dirs(FIG_DIR, CSV_DIR)

    # Models used in robustness: Linear, MLP(h=4), VQC(L=1 shots=1024), VQC(L=2 shots=1024)
    specs = []
    specs.append((*make_linear(), LR_HP))
    specs.append((*make_mlp(h=4), MLP_HP))
    specs.append((*make_vqc(L=1, shots=1024), VQC_HP))
    specs.append((*make_vqc(L=2, shots=1024), VQC_HP))

    # ---------- (a) Noise sweep ----------
    all_records_noise = []
    all_summaries_noise = []

    for spec, factory, hp in specs:
        rec, summ = sweep_noise_datasetB(
            sigmas=NOISE_SWEEP,
            n_per_cluster=100,
            model_factory=factory,
            model_name=spec.name,
            train_cfg=TrainConfig(hp.epochs, hp.lr),
            data_seed=DATASET_SEED,
            split_seed=SPLIT_SEED,
            model_seeds=MODEL_SEEDS,
        )
        all_records_noise.extend(rec)
        all_summaries_noise.extend(summ)

    save_records_csv(os.path.join(CSV_DIR, "robustness_noise_runs.csv"), all_records_noise)
    save_summaries_csv(os.path.join(CSV_DIR, "robustness_noise_summary.csv"), all_summaries_noise)

    # Plot: one curve per model (mean±std)
    for spec, _, _ in specs:
        sub = [s for s in all_summaries_noise if s["model_name"] == spec.name]
        sub = sorted(sub, key=lambda r: r["sigma"])
        xs = [r["sigma"] for r in sub]
        ys_m = [r["test_acc_mean"] for r in sub]
        ys_s = [r["test_acc_std"] for r in sub]
        plot_mean_std_curve(
            xs=xs, ys_mean=ys_m, ys_std=ys_s,
            title=f"Dataset B (n=100): Accuracy vs noise — {spec.name}",
            xlabel="noise σ", ylabel="test accuracy",
            label=spec.name,
            out_path=os.path.join(FIG_DIR, f"rob_noise_{spec.name.replace(' ', '').replace('=', '')}.png"),
        )

    # ---------- (b) Size sweep ----------
    all_records_size = []
    all_summaries_size = []

    for spec, factory, hp in specs:
        rec, summ = sweep_size_datasetB(
            sizes=SIZE_SWEEP,
            sigma=0.10,
            model_factory=factory,
            model_name=spec.name,
            train_cfg=TrainConfig(hp.epochs, hp.lr),
            data_seed=DATASET_SEED,
            split_seed=SPLIT_SEED,
            model_seeds=MODEL_SEEDS,
        )
        all_records_size.extend(rec)
        all_summaries_size.extend(summ)

    save_records_csv(os.path.join(CSV_DIR, "robustness_size_runs.csv"), all_records_size)
    save_summaries_csv(os.path.join(CSV_DIR, "robustness_size_summary.csv"), all_summaries_size)

    for spec, _, _ in specs:
        sub = [s for s in all_summaries_size if s["model_name"] == spec.name]
        sub = sorted(sub, key=lambda r: r["n_per_cluster"])
        xs = [r["n_per_cluster"] for r in sub]
        ys_m = [r["test_acc_mean"] for r in sub]
        ys_s = [r["test_acc_std"] for r in sub]
        plot_mean_std_curve(
            xs=xs, ys_mean=ys_m, ys_std=ys_s,
            title=f"Dataset B (σ=0.10): Accuracy vs dataset size — {spec.name}",
            xlabel="n_per_cluster", ylabel="test accuracy",
            label=spec.name,
            out_path=os.path.join(FIG_DIR, f"rob_size_{spec.name.replace(' ', '').replace('=', '')}.png"),
        )


if __name__ == "__main__":
    main()
