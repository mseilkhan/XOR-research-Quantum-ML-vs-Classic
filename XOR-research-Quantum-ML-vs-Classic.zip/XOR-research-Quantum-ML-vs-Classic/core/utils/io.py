from __future__ import annotations

import os
import csv
from typing import Dict, Iterable, List, Any


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def write_csv_rows(path: str, fieldnames: List[str], rows: Iterable[Dict[str, Any]]) -> None:
    """Write list of dict rows to CSV."""
    ensure_dir(os.path.dirname(path) or ".")
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def read_csv_rows(path: str) -> List[Dict[str, str]]:
    """Read CSV into list of dict rows (all values as strings)."""
    with open(path, "r", newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        return list(r)
