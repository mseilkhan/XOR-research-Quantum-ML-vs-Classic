from __future__ import annotations

from typing import Optional, Sequence, Tuple
import numpy as np
import matplotlib.pyplot as plt

from core.viz.style import apply_plot_style


def make_grid(xlim=(0.0, 1.0), ylim=(0.0, 1.0), n: int = 250) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    xs = np.linspace(xlim[0], xlim[1], int(n))
    ys = np.linspace(ylim[0], ylim[1], int(n))
    XX, YY = np.meshgrid(xs, ys)
    grid = np.stack([XX.ravel(), YY.ravel()], axis=1)
    return XX, YY, grid


def plot_decision_function(
    *,
    model,
    X: np.ndarray,
    y: np.ndarray,
    title: str,
    out_path: Optional[str] = None,
    xlim=(0.0, 1.0),
    ylim=(0.0, 1.0),
    n_grid: int = 250,
    show_boundary: bool = True,
    vmin: float = 0.0,
    vmax: float = 1.0,
) -> None:
    """
    Decision function visualization using probability p(y=1|x).
    Boundary at p=0.5 (optional).
    """
    apply_plot_style()
    XX, YY, grid = make_grid(xlim=xlim, ylim=ylim, n=n_grid)
    P = model.predict_proba(grid).reshape(XX.shape)

    fig = plt.figure(figsize=(6, 6))
    ax = plt.gca()

    im = ax.imshow(P, origin="lower",
                   extent=(xlim[0], xlim[1], ylim[0], ylim[1]),
                   vmin=vmin, vmax=vmax, aspect="equal")

    if show_boundary:
        ax.contour(XX, YY, P, levels=[0.5], linewidths=2.0)

    # scatter data
    ax.scatter(X[:, 0], X[:, 1], c=y, s=18, edgecolors="k", linewidths=0.3)

    ax.set_title(title)
    ax.set_xlabel("x1")
    ax.set_ylabel("x2")
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    if out_path is not None:
        fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


def plot_decision_boundary_seed_background(
    *,
    models: Sequence,
    X: np.ndarray,
    y: np.ndarray,
    title: str,
    out_path: Optional[str] = None,
    xlim=(0.0, 1.0),
    ylim=(0.0, 1.0),
    n_grid: int = 250,
) -> None:
    """
    "Representative background across seeds":
    - draw multiple seed boundaries with low alpha
    - overlay final/primary boundary using the first model
    """
    apply_plot_style()
    XX, YY, grid = make_grid(xlim=xlim, ylim=ylim, n=n_grid)

    fig = plt.figure(figsize=(6, 6))
    ax = plt.gca()

    # background contours per seed
    for m in models:
        P = m.predict_proba(grid).reshape(XX.shape)
        ax.contour(XX, YY, P, levels=[0.5], linewidths=1.0, alpha=0.18)

    # main heatmap from first model
    P0 = models[0].predict_proba(grid).reshape(XX.shape)
    im = ax.imshow(P0, origin="lower",
                   extent=(xlim[0], xlim[1], ylim[0], ylim[1]),
                   vmin=0.0, vmax=1.0, aspect="equal", alpha=0.95)

    ax.scatter(X[:, 0], X[:, 1], c=y, s=18, edgecolors="k", linewidths=0.3)
    ax.set_title(title)
    ax.set_xlabel("x1")
    ax.set_ylabel("x2")
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    if out_path is not None:
        fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
